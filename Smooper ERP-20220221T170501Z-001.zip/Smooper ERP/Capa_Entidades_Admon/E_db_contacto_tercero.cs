﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Entidades_Admon
{
    public struct E_db_contacto_tercero
    {
        public string Id { get; set; }
        public string Contacto { get; set; }
        public string Cargo { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public string Foto { get; set; }
        public string Celular { get; set; }       
        public string Nit_empresa { get; set; }

    }
}

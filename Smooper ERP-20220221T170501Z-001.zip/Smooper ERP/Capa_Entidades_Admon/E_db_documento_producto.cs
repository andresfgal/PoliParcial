﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Entidades_Admon
{
    public class E_db_documento_producto
    {
        [BsonElement("_id")]
        public ObjectId _id { get; set; }
        public string Nombre { get; set; }
        public string Documento { get; set; }
        public string Fecha_expedicion { get; set; }
        public string Codigo_Producto { get; set; }

    }
}

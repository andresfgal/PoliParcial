﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Capa_Entidades_Admon
{
    public struct E_db_Producto
    {
        public string Id { get; set; }
        public string Codigo { get; set; }
        public string Descripcion1 { get; set; }
        public string Descripcion2 { get; set; }
        public string RefProvedor { get; set; }
        public string Precio { get; set; }
        public string Precio2 { get; set; }
        public string Estado{ get; set; }
        public string Provedor { get; set; }
        public string Imagen { get; set; }

        public string UnM { get; set; }
        public string Costo{ get; set; }
        public string Costo_Promedio{ get; set; }



    }
    public class Producto
    {
        private ImageSource _Imagen;        
        private string _Descripcion;
        private string _Codigo;
        private string _Precio;        
        private ImageSource _Habilitado;
        private ImageSource _Inhabilitado;        
        private string _T;
        private string _F;        
        public Producto(ImageSource image, string descripcion, string codigo, string precio, ImageSource habilitado, ImageSource inhabilitado, string t, string f)
        {
            _Imagen = image;
            _Descripcion = descripcion;
            _Codigo = codigo;
            _Precio = precio;
            _Habilitado = habilitado;
            _Inhabilitado = inhabilitado;
            _T = t;
            _F = f;
         
        }


        public ImageSource Imagen { get { return _Imagen; } }
        public string Descripcion { get { return _Descripcion; } }

        public string Codigo{ get { return _Codigo; } }
        public string Precio { get { return _Precio; } }
        public ImageSource Habilitado{ get { return _Habilitado; } }
        public ImageSource Inhabilitado { get { return _Inhabilitado; } }
     
        public string T { get { return _T; } }
        public string F { get { return _F; } }
   
    }
}


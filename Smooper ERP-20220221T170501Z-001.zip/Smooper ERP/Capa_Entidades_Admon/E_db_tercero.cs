﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Entidades_Admon
{
    public struct E_db_tercero
    {
        public string Nit { get; set; }
        public string Cod_Ver{ get; set; }
        public string Tipo_Persona { get; set; }
        public string Tipo_Id { get; set; }
        public string Razon_Social { get; set; }
        public string Actividad { get; set; }
        public string Nombre_Comercial { get; set; }
        public string Cliente { get; set; }
        public string Provedor { get; set; }
        public string Banco { get; set; }
        public string Telefono { get; set; }
        public string Celular { get; set; }
        public string Web { get; set; }
        public string Email { get; set; }
        public string Logo { get; set; }
        public string Path{ get; set; }
        public string Nombre { get; set; }
        public string Nombre2 { get; set; }
        public string Apellido { get; set; }
        public string Apellido2 { get; set; }
        public string Etiquetas { get; set; }
        public string Etiquetas_des { get; set; }

    }


}

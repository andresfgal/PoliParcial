﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Entidades_Admon
{
    public struct E_db_etiquetas
    {
        public string Id { get; set; }
        public string Codigo { get; set; }
        public string Nombre { get; set; }
        public string Color{ get; set; }
    }
}

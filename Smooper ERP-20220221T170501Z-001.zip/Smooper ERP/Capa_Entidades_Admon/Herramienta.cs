﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace Capa_Entidades_Admon
{
   
    public class Herramienta
    {
        private ImageSource _Imagen;
        private string _Descripcion;
        
        public Herramienta(ImageSource image, string descripcion)
        {
            _Imagen = image;
            _Descripcion = descripcion;
     

        }


        public ImageSource Imagen { get { return _Imagen; } }
        public string Descripcion { get { return _Descripcion; } }
      


    }

}

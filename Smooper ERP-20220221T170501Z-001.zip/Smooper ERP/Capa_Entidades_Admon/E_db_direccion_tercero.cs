﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Entidades_Admon
{


    public struct E_db_direccion_tercero
    {
        public string Id { get; set; }
        public string descripcion { get; set; }
        public string direccion { get; set; }
        public string Nit_tercero{ get; set; }
        public string Pais { get; set; }
        public string Departamento { get; set; }
        public string Municipio { get; set; }
        public string Codigo_Postal { get; set; }
        public string Detalles { get; set; }
        public int Principal { get; set; }

    }
}
﻿using Capa_Entidades_Inventario;
using Capa_Notificaciones;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Datos_Inventario
{
    public class D_Update
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();
        private Windows window = new Windows();

        /// <summary>
        /// Actualiza  Bodega seleccionada 
        /// </summary>
        /// <param name="bodega"></param>
        public void Contacto_Tercero(E_db_Bodega bodega)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Update_Inventario_Bodega", connection)
                {
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Id", bodega.Id);
                command.Parameters.AddWithValue("@Descipcion", bodega.Descripcion);
                command.Parameters.AddWithValue("@Peso", bodega.Peso);
                command.Parameters.AddWithValue("@Dimension", bodega.Dimension);
                command.Parameters.AddWithValue("@Id_Ref", bodega.Id_Ref);
                command.Parameters.AddWithValue("@Tipo", bodega.Tipo);

                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                window.Error("\nError code: " + e.ErrorCode, e.StackTrace);

            }
        }
    }
}

﻿using Capa_Notificaciones;
using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace Capa_Datos_Inventario
{
    public class D_Select
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();

        /// <summary>
        /// Consulta de Bodegas
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable Bodegas()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Inventario_BodegasPr", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        public DataTable Terceros_Provedores()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Terceros_Provedor", connection);
                
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        public DataTable Productos_Provedor(String Nit)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Productos_Provedor", connection);
                command.Parameters.AddWithValue("@Provedor", Nit);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta Unidad Medida Producto
        /// </summary>
        /// <param name="id"></param>
        /// <returns> True or False</returns>
        public string UM(string id)
        {
            try
            {

                string UM;
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_UnM_Id", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", id);
                UM = command.ExecuteScalar().ToString();
                connection = conexion.Desconectar(connection);
                return UM;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }


        /// <summary>
        /// Consulta Lotes
        /// </summary>
        /// <param name="id"></param>
        /// <returns> True or False</returns>
        public DataTable Lotes()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Lotes", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }


    }
}

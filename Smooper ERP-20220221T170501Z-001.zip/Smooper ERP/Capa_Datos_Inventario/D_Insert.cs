﻿using Capa_Entidades_Inventario;
using Capa_Notificaciones;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Datos_Inventario
{
    public class D_Insert
    {
        private ConexionMySql conexion = new ConexionMySql();
        private MySqlConnection connection = new MySqlConnection();
        private Windows window = new Windows();

        /// <summary>
        /// Inserta Bodega
        /// </summary>
        /// <param name="bodega"></param>        
        public void Bodega(E_db_Bodega bodega)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_Inventario_Bodega", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;                
                command.Parameters.AddWithValue("@Descripcion", bodega.Descripcion);
                command.Parameters.AddWithValue("@Peso", bodega.Peso);
                command.Parameters.AddWithValue("@Dimension", bodega.Dimension);
                command.Parameters.AddWithValue("@Id_Ref", bodega.Id_Ref);
                command.Parameters.AddWithValue("@Tipo", bodega.Tipo);


                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                window.Error(e.ToString(), e.StackTrace);

            }
            finally
            {
                connection.Close();
            }
        }


        /// <summary>
        /// Inserta Bodega
        /// </summary>
        /// <param name="lote"></param>        
        public void Lote(E_db_Lote lote)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_Lote_Inventario", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@N_Lote",lote.N_Lote);
                command.Parameters.AddWithValue("@F_Creacion",lote.F_Creacion );
                command.Parameters.AddWithValue("@F_Vencimiento", lote.F_Vencimiento);



                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                window.Error(e.ToString(), e.StackTrace);

            }
            finally
            {
                connection.Close();
            }
        }

        public static implicit operator D_Insert(D_Select v)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using Capa_Notificaciones;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Capa_Datos_Inventario
{
   public class D_Delete
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();
        private Windows window = new Windows();
        /// <summary>
        /// Elimina una bodega 
        /// </summary>
        /// <param name="Id"></param>
        public void Bodega(string Id)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Delete_Inventario_Bodega", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", Id);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                window.Alerta("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }
    }
}

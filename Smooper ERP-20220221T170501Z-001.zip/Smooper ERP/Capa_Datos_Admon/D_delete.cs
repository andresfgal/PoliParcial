﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using Capa_Notificaciones;

namespace Capa_Datos_Admon
{
    public class D_delete
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();
        private Windows window = new Windows();
        /// <summary>
        /// Elimina un tercero
        /// </summary>
        /// <param name="Nit"></param>
        public void Tercero(string Nit)
        {
            try
            {                
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Delete_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", Nit);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);
                

            }
            catch (MySqlException e)
            {
                window.Alerta("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
   
            }
        }

        /// <summary>
        /// Elimina  contacdo seleccionado de un  tercero
        /// </summary>
        /// <param name="Nit"></param>
        public void Contacto_Tercero(string Id)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Delete_Contacto_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", Id);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);
               
                

            }
            catch (MySqlException e)
            {
                window.Alerta("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }
        /// <summary>
        /// Elimina  direccion seleccionada de un  tercero
        /// </summary>
        /// <param name="Id"></param>
        public void Direccion_Tercero(string Id)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Delete_Direccion_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", Id);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                window.Alerta("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }
        /// <summary>
        /// Elimina  producto
        /// </summary>
        /// <param name="Codigo"></param>
        public void Producto(string Codigo)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Delete_Producto", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", Codigo);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                window.Alerta("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }
    }
}

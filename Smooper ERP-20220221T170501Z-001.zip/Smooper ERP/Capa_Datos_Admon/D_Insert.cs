﻿using Capa_Entidades_Admon;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using Capa_Notificaciones;
using MongoDB.Driver;
using MongoDB.Driver.GridFS;
using MongoDB.Bson;
using System.IO;
using System.IO.Compression;
using ICSharpCode.SharpZipLib.Zip;
using System.Data;

namespace Capa_Datos_Admon
{
    public class D_Insert
    {
        private ConexionMySql conexion = new ConexionMySql();
        private MySqlConnection connection = new MySqlConnection();
        private Windows window = new Windows();

        /// <summary>
        /// Inserta Tercero
        /// </summary>
        /// <param name="tercero"></param>        
        public void Tercero(E_db_tercero tercero)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", tercero.Nit);
                command.Parameters.AddWithValue("@Tipo_Persona", tercero.Tipo_Persona);
                command.Parameters.AddWithValue("@Cod_Ver", tercero.Cod_Ver);
                command.Parameters.AddWithValue("@Tipo_Id", tercero.Tipo_Id);
                command.Parameters.AddWithValue("@Razon_social", tercero.Razon_Social);
                command.Parameters.AddWithValue("@Actividad", tercero.Actividad);
                command.Parameters.AddWithValue("@Nombre_comercial", tercero.Nombre_Comercial);
                command.Parameters.AddWithValue("@Cliente", tercero.Cliente);
                command.Parameters.AddWithValue("@Provedor", tercero.Provedor);
                command.Parameters.AddWithValue("@Banco", tercero.Banco);
                command.Parameters.AddWithValue("@Telefono", tercero.Telefono);
                command.Parameters.AddWithValue("@Celular", tercero.Celular);
                command.Parameters.AddWithValue("@Web", tercero.Web);
                command.Parameters.AddWithValue("@Email", tercero.Email);
                command.Parameters.AddWithValue("@Logo", tercero.Logo);
                command.Parameters.AddWithValue("@NLogo", tercero.Path);
                command.Parameters.AddWithValue("@Nombre", tercero.Nombre);
                command.Parameters.AddWithValue("@Nombre2", tercero.Nombre2);
                command.Parameters.AddWithValue("@Apellido", tercero.Apellido);
                command.Parameters.AddWithValue("@Apellido2", tercero.Apellido2);
                command.Parameters.AddWithValue("@Etiquetas", tercero.Etiquetas);
                command.Parameters.AddWithValue("@Etiquetas_des", tercero.Etiquetas_des);

                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());

            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Inserta Contacto de un Tercero
        /// </summary>
        /// <param name="contacto"></param>        
        public void Contacto_Tercero(E_db_contacto_tercero contacto)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_contacto_tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Contacto", contacto.Contacto);
                command.Parameters.AddWithValue("@Cargo", contacto.Cargo);
                command.Parameters.AddWithValue("@Telefono", contacto.Telefono);
                command.Parameters.AddWithValue("@Email", contacto.Email);
                command.Parameters.AddWithValue("@Celular", contacto.Celular);
                command.Parameters.AddWithValue("@Foto", contacto.Foto);
                command.Parameters.AddWithValue("@Nit_empresa", contacto.Nit_empresa);



                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());

            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Inserta etiqueta
        /// </summary>
        /// <param name="etiqueta"></param>        
        public void Etiqueta_tercero(E_db_etiquetas etiqueta)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_Etiqueta_tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", etiqueta.Codigo);
                command.Parameters.AddWithValue("@Nombre", etiqueta.Nombre);
                command.Parameters.AddWithValue("@Color", etiqueta.Color);


                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());

            }
            finally
            {
                connection.Close();
            }
        }
        /// <summary>
        /// Inserta Direccion de un Tercero
        /// </summary>
        /// <param name="direccion"></param>        
        public void Direccion_Tercero(E_db_direccion_tercero direccion)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_direccion_tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@descripcion", direccion.descripcion);
                command.Parameters.AddWithValue("@direccion", direccion.direccion);
                command.Parameters.AddWithValue("@Nit_tercero", direccion.Nit_tercero);
                command.Parameters.AddWithValue("@Pais", direccion.Pais);
                command.Parameters.AddWithValue("@Departamento", direccion.Departamento);
                command.Parameters.AddWithValue("@Municipio", direccion.Municipio);
                command.Parameters.AddWithValue("@Codigo_Postal", direccion.Codigo_Postal);
                command.Parameters.AddWithValue("@Detalles", direccion.Detalles);
                command.Parameters.AddWithValue("@Principal", direccion.Principal);



                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());

            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Inserta Producto
        /// </summary>
        /// <param name="contacto"></param>        
        public void Producto(E_db_Producto producto)
        {

            connection = conexion.Conectar(connection);

            try
            {
                MySqlCommand command = new MySqlCommand("Insert_Producto", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", producto.Codigo);
                command.Parameters.AddWithValue("@Descripcion", producto.Descripcion1);
                command.Parameters.AddWithValue("@Descripcion_2", producto.Descripcion2);
                command.Parameters.AddWithValue("@RefProvedor", producto.RefProvedor);
                command.Parameters.AddWithValue("@Precio", producto.Precio);
                command.Parameters.AddWithValue("@Precio_2", producto.Precio2);
                command.Parameters.AddWithValue("@Estado", producto.Estado);
                command.Parameters.AddWithValue("@Provedor", producto.Provedor);
                command.Parameters.AddWithValue("@imagen", producto.Imagen);
                command.Parameters.AddWithValue("@Unidad_Medida", producto.UnM);
                command.Parameters.AddWithValue("@Costo", producto.Costo);
                command.Parameters.AddWithValue("@Costo_Promedio", producto.Costo_Promedio);



                window.Notificacion(command.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());

            }
            finally
            {
                connection.Close();
            }
        }








    }
}

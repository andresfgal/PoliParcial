﻿using Capa_Notificaciones;
using MySql.Data.MySqlClient;
using System;
using System.Data;

namespace Capa_Datos_Admon
{
    public class D_Select
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();

        /// <summary>
        /// Consulta de Terceros
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable Terceros()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Terceros", connection);
                command.CommandType = CommandType.StoredProcedure;                
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta de Terceros por filtro
        /// </summary>
        /// <param name="Filtro"></param>
        /// <returns>Información de los Terceros</returns>
        public DataTable Filtro_Terceros(string[] Filtro)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Terceros_Dinamico", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Filtro",Filtro[0]);
                command.Parameters.AddWithValue("@Cliente", Filtro[1].ToString()) ;
                command.Parameters.AddWithValue("@Provedor", Filtro[2].ToString());
                command.Parameters.AddWithValue("@Banco", Filtro[3].ToString());
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta contactos de terceros
        /// </summary>
        /// <param name="Nit"></param>
        /// <returns>Información de contactos de Terceros</returns>
        public DataTable Contactos_Tercero(string Nit)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_Contactos_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", Nit);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta contactos de terceros
        /// </summary>
        /// <param name="Nit"></param>
        /// <returns>Información de contactos de Terceros</returns>
        public DataTable Contactos_Tercero_Filtro(string Nit,string Filtro)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_Contactos_Tercero_Filtro", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", Nit);
                command.Parameters.AddWithValue("@Filtro", Filtro);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta Direccion de terceros
        /// </summary>
        /// <param name="Nit"></param>
        /// <returns>Información de contactos de Terceros</returns>
        public DataTable Direcciones_Tercero(string Nit)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_Direcciones_Tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", Nit);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta existencia de un tercero
        /// </summary>
        /// <param name="Nit"></param>
        /// <returns> True or False</returns>
        public int Existencia_Tercero(string Nit)
        {
            try
            {

                int valor;
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_existencia_tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit", Nit);
                valor=Convert.ToInt32(command.ExecuteScalar());
                connection = conexion.Desconectar(connection);
                return valor;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return 0;
            }
        }

        /// <summary>
        /// Consulta Etiquetas
        /// </summary>     
        
        public DataTable Etiquetas()
        {
            try
            {

                DataTable valor = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_Etiquetas_tercero", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;                
                
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(valor);
                connection = conexion.Desconectar(connection);
                return valor;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta etiquetas de terceros por id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Información de etiqeutas de Terceros</returns>
        public DataTable Etiquetas_Id(string Id)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("select_etiquetas_id", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", Id);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta de paises
        /// </summary>
        /// <returns>Lista de paises </returns>
        public DataTable Paises()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Paises", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta de Departamentos
        /// </summary>
        /// <returns>Lista de departamentos</returns>
        public DataTable Dptos(string Codigo)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Departamentos", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", Codigo);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta de Departamentos
        /// </summary>
        /// <returns>Lista de departamentos</returns>
        public DataTable Ciudades(string Codigo, int indicativo)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Municipios", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", Codigo);
                command.Parameters.AddWithValue("@ind", indicativo);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        public DataTable Terceros_Provedores()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Terceros_Provedor", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }


        /// <summary>
        /// Consulta de Productos
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable Productos()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Productos", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta de Unidades de Medida
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable UnM()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_UnM", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }
        /// <summary>
        /// Consulta existencia de un producto
        /// </summary>
        /// <param name="Codigo"></param>
        /// <returns> True or False</returns>
        public int Existencia_Producto(string Codigo)
        {
            try
            {

                int valor;
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Existencia_Producto", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Codigo", Codigo);
                valor = Convert.ToInt32(command.ExecuteScalar());
                connection = conexion.Desconectar(connection);
                return valor;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return 0;
            }
        }

        /// <summary>
        /// Consulta existencia de una direccion principal
        /// </summary>
        /// <param name="Nit"></param>
        /// <returns> True or False</returns>
        public int Existencia_DireccionPrincipal(string Nit)
        {
            try
            {

                int valor;
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Admon_Dir_Principal", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Nit_tercero", Nit);
                valor = Convert.ToInt32(command.ExecuteScalar());
                connection = conexion.Desconectar(connection);
                return valor;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return 0;
            }
        }
        /// <summary>
        /// Consulta de Productos por filtro
        /// </summary>
        /// <param name="Filtro"></param>
        /// <returns>Información de los Terceros</returns>
        public DataTable Filtro_Productos(string Filtro, string Estado)
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Productos_Dinamico", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Filtro", Filtro);
                command.Parameters.AddWithValue("@Estado", Estado);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }


        /// <summary>
        /// Consulta Modulo Administacion
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable Modulo_Admon ()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Modulo_Admon", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Consulta Modulo Administacion
        /// </summary>
        /// <returns>Información de los Terceros</returns>
        public DataTable Modulo_Admon_Herramientas()
        {
            try
            {

                DataTable dt = new DataTable();
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Select_Modulo_Admon_True", connection);
                command.CommandType = CommandType.StoredProcedure;
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter(command);
                mySqlDataAdapter.Fill(dt);
                connection = conexion.Desconectar(connection);
                return dt;
            }
            catch (MySqlException e)
            {
                Console.WriteLine("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);
                return null;
            }
        }

    }
}


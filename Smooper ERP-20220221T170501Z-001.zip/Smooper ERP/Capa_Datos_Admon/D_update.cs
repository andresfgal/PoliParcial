﻿using Capa_Entidades_Admon;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using Capa_Notificaciones;

namespace Capa_Datos_Admon
{
  
    public class D_update
    {
        private MySqlConnection connection = new MySqlConnection();
        private ConexionMySql conexion = new ConexionMySql();
        private Windows window = new Windows();
 
        /// <summary>
        /// Actualuza un tercero
        /// </summary>
        /// <param name="tercero"></param>
        public void Tercero(E_db_tercero tercero)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Update_Tercero", connection)
                {
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Nit", tercero.Nit);                
                command.Parameters.AddWithValue("@Tipo_Id", tercero.Tipo_Id);
                command.Parameters.AddWithValue("@Tipo_Persona", tercero.Tipo_Persona);
                command.Parameters.AddWithValue("@Razon_social", tercero.Razon_Social);
                command.Parameters.AddWithValue("@Actividad", tercero.Actividad);
                command.Parameters.AddWithValue("@Nombre_comercial", tercero.Nombre_Comercial);
                command.Parameters.AddWithValue("@Cliente", tercero.Cliente);
                command.Parameters.AddWithValue("@Provedor", tercero.Provedor);
                command.Parameters.AddWithValue("@Banco", tercero.Banco);
                command.Parameters.AddWithValue("@Telefono", tercero.Telefono);
                command.Parameters.AddWithValue("@Celular", tercero.Celular);
                command.Parameters.AddWithValue("@Web", tercero.Web);
                command.Parameters.AddWithValue("@Email", tercero.Email);
                command.Parameters.AddWithValue("@Logo", tercero.Logo);
                command.Parameters.AddWithValue("@NLogo", tercero.Path);
                command.Parameters.AddWithValue("@Nombre", tercero.Nombre);
                command.Parameters.AddWithValue("@Nombre2", tercero.Nombre2);
                command.Parameters.AddWithValue("@Apellido", tercero.Apellido);
                command.Parameters.AddWithValue("@Apellido2", tercero.Apellido2);
                command.Parameters.AddWithValue("@Etiquetas", tercero.Etiquetas);
                command.Parameters.AddWithValue("@Etiquetas_des", tercero.Etiquetas_des);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);
              

            }
            catch (MySqlException e)
            {
                MessageBox.Show("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }

        /// <summary>
        /// Actualiza  contacto seleccionado de un  tercero
        /// </summary>
        /// <param name="contacto"></param>
        public void Contacto_Tercero(E_db_contacto_tercero contacto)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Update_Contacto_Tercero", connection)
                {
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Id", contacto.Id);
                command.Parameters.AddWithValue("@Contacto", contacto.Contacto);
                command.Parameters.AddWithValue("@Cargo", contacto.Cargo);
                command.Parameters.AddWithValue("@Telefono", contacto.Telefono);
                command.Parameters.AddWithValue("@Celular", contacto.Celular);
                command.Parameters.AddWithValue("@Email", contacto.Email);
                command.Parameters.AddWithValue("@Nit_empresa", contacto.Nit_empresa);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);
                

            }
            catch (MySqlException e)
            {
                MessageBox.Show("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }

        /// <summary>
        /// Actualiza  producto seleccionado 
        /// </summary>
        /// <param name="producto"></param>
        public void Producto(E_db_Producto producto)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Update_Producto", connection)
                {
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Codigo", producto.Codigo);
                command.Parameters.AddWithValue("@Descripcion", producto.Descripcion1);
                command.Parameters.AddWithValue("@Descripcion_2", producto.Descripcion2);
                command.Parameters.AddWithValue("@RefProvedor",producto.RefProvedor);
                command.Parameters.AddWithValue("@Precio", producto.Precio);
                command.Parameters.AddWithValue("@Precio_2", producto.Precio2);                
                command.Parameters.AddWithValue("@Estado", producto.Estado);
                command.Parameters.AddWithValue("@Provedor", producto.Provedor);
                command.Parameters.AddWithValue("@imagen", producto.Imagen);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                MessageBox.Show("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }

        /// <summary>
        /// Actualiza  producto seleccionado 
        /// </summary>
        /// <param name="dir"></param>
        public void Dir_Principal(E_db_direccion_tercero dir)
        {
            try
            {
                connection = conexion.Conectar(connection);
                MySqlCommand command = new MySqlCommand("Update_Dir_Principal", connection)
                {
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                command.Parameters.AddWithValue("@Nit_tercero", dir.Nit_tercero);
                command.Parameters.AddWithValue("@Principal", dir.Principal);
                window.Notificacion(command.ExecuteScalar().ToString());
                connection = conexion.Desconectar(connection);


            }
            catch (MySqlException e)
            {
                MessageBox.Show("\nError code: " + e.ErrorCode + "\nMessage: " + e.Message + "\nStackTrace" + e.StackTrace);

            }
        }
    }
}

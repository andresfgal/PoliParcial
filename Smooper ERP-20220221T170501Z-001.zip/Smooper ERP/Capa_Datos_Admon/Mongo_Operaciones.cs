﻿using Capa_Entidades_Admon;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Linq;
using System.Collections.Generic;
using MongoDB.Driver.GridFS;
using System.IO;
using System.Diagnostics;
using Capa_Notificaciones;
using System;
using System.Threading.Tasks;

namespace Capa_Datos_Admon
{
    public class Mongo_Operaciones
    {
        public static string usuario { get; set; } = string.Empty;
        public static string password { get; set; } = string.Empty;
        public static string servidor { get; set; } = string.Empty;
        public static string db { get; set; } = string.Empty;
        public static string port { get; set; } = string.Empty;

        private ConexionMongoDB Mongo = new ConexionMongoDB();

        /// <summary>
        /// Abre la conexión con la base de datos 
        /// </summary>
        public IMongoDatabase ConexionMongo()
        {
            try
            {

                string connectionString = "mongodb://" + usuario + ":" + password + "@" + servidor + ":" + port + "/" + db;
                var mc = new MongoClient(connectionString);
                var database = mc.GetDatabase("Smooper_ERP_data");
                return database;
            }
            catch (MongoClientException ex)
            {

                new Windows().Error(ex.ToString(), ex.StackTrace);
                return null;
            }

        }


        /// <summary>
        /// Inserta documento de un Tercero
        /// </summary>
        /// <param name="documento"></param>   
        public async Task<bool> Documento_Tercero(E_db_documento_tercero documento)
        {

            var database = Mongo.Conexion();

            var client = database.Client;
            var fs = new GridFSBucket(database);
            string Nombre = Path.GetFileName(documento.Documento);
            var s = File.OpenRead(documento.Documento);

            using (var session = await client.StartSessionAsync())
            {
                session.StartTransaction();
                try
                {
                    documento._id = await fs.UploadFromStreamAsync(Nombre, s);

                    documento.Documento = Nombre;
                    var collection = database.GetCollection<E_db_documento_tercero>("documentos_encabezado");
                    await collection.InsertOneAsync(documento);
                    await session.CommitTransactionAsync();
                }

                catch (Exception e)
                {
                    Console.WriteLine("Error insertando datos en MongoDB: " + e.Message);
                    await session.AbortTransactionAsync();
                    return false;
                }

                return true;


            }



        }
        /// <summary>
        /// Consulta de documentos de un Tercero filtrado por nit
        /// </summary>
        /// <param name="nit"></param>   
        /// <returns>Lista de documentos de un tercero</returns>
        public List<E_db_documento_tercero> Collecion_Documentos(string nit)

        {
            var database = Mongo.Conexion();
            var collection = database.GetCollection<E_db_documento_tercero>("documentos_encabezado");
            var result = collection.AsQueryable().Where(e => e.Nit_tercero == nit);
            List<E_db_documento_tercero> resultList = result.ToList();
            return resultList;

        }

        /// <summary>
        /// Descarga de documentos de un Tercero 
        /// </summary>
        /// <param name="documento"></param>           
        public async void Descargar_documento(E_db_documento_tercero documento)
        {
            var database = Mongo.Conexion();
            var fs = new GridFSBucket(database);
            var des1 = File.Create(Path.GetTempPath() + "\\" + documento.Documento);
            await fs.DownloadToStreamAsync(documento._id, des1);
            des1.Close();
            Process proceso = new Process();
            proceso.StartInfo.FileName = Path.GetTempPath() + "\\" + documento.Documento;
            proceso.Start();
            proceso.WaitForExit();

        }

        /// <summary>
        /// Actualiza un documento de un Tercero 
        /// </summary>
        /// <param name="documento"></param>  
        /// <param name="estado"></param>  
        public async Task Editar_documento(E_db_documento_tercero documento, bool estado)
        {
            var database = Mongo.Conexion();
            var client = database.Client;
            //var database = MongoClient().GetDatabase("Smooper_ERP_data");
            using (var session = await client.StartSessionAsync())
            {
                session.StartTransaction();
                try
                {

                    var collection = database.GetCollection<E_db_documento_tercero>("documentos_encabezado");
                    var filter = Builders<E_db_documento_tercero>.Filter.Eq("_id", documento._id);
                    if (estado)
                    {
                        collection.DeleteOne(filter);
                        var fs = new GridFSBucket(database);
                        fs.Delete(documento._id);
                        if (!await Documento_Tercero(documento))
                        {
                            Environment.Exit(1);
                        }
                        new Windows().Notificacion("Documento actualizado con exito");
                    }
                    else
                    {



                        var update = Builders<E_db_documento_tercero>.Update.Set(s => s.Nombre, documento.Nombre).Set(s => s.Documento, documento.Documento).Set(s => s.Fecha_expedicion, documento.Fecha_expedicion);
                        collection.UpdateOne(filter, update);


                    }
                    await session.CommitTransactionAsync();
                    new Windows().Alerta("Documento actualizado con exito");
                }

                catch (Exception ex)
                {
                    Console.WriteLine("Error actualizando datos en MongoDB: " + ex.Message);
                    new Windows().Alerta("El registro no se actualizo");

                    await session.AbortTransactionAsync();


                }

            }


        }

        /// <summary>
        /// Elimina un documento de un Tercero 
        /// </summary>
        /// <param name="_id"></param>          

   
        public async Task<bool> Eliminar_Documento(ObjectId _id)
        {

            var database = Mongo.Conexion();

            var client = database.Client;

            using (var session = await client.StartSessionAsync())
            {
                session.StartTransaction();
                try
                {
                    var collection = database.GetCollection<E_db_documento_tercero>("documentos_encabezado");
                    var filter = Builders<E_db_documento_tercero>.Filter.Eq("_id", _id);
                    collection.DeleteOne(filter);
                    var fs = new GridFSBucket(database);
                    fs.Delete(_id);
                    await session.CommitTransactionAsync();
                }

                catch (Exception e)
                {
                    Console.WriteLine("Error eliminando datos en MongoDB: " + e.Message);
                    await session.AbortTransactionAsync();
                    return false;
                }

                return true;


            }
        }


        /// <summary>
        /// Inserta documento de un producto
        /// </summary>
        /// <param name="documento"></param>   
        public async Task<bool> Documento_Producto(E_db_documento_producto documento)
        {

            var database = Mongo.Conexion();

            var client = database.Client;
            var fs = new GridFSBucket(database);
            string Nombre = Path.GetFileName(documento.Documento);
            var s = File.OpenRead(documento.Documento);

            using (var session = await client.StartSessionAsync())
            {
                session.StartTransaction();
                try
                {
                    documento._id = await fs.UploadFromStreamAsync(Nombre, s);

                    documento.Documento = Nombre;
                    var collection = database.GetCollection<E_db_documento_producto>("documentos_encabezado_producto");
                    await collection.InsertOneAsync(documento);
                    await session.CommitTransactionAsync();
                }

                catch (Exception e)
                {
                    Console.WriteLine("Error insertando datos en MongoDB: " + e.Message);
                    await session.AbortTransactionAsync();
                    return false;
                }

                return true;


            }



        }
        /// <summary>
        /// Consulta de documentos de un Tercero filtrado por nit
        /// </summary>
        /// <param name="nit"></param>   
        /// <returns>Lista de documentos de un tercero</returns>
        public List<E_db_documento_producto> Collecion_Documentos_Producto(string Codigo)

        {
            var database = Mongo.Conexion();
            var collection = database.GetCollection<E_db_documento_producto>("documentos_encabezado_producto");
            var result = collection.AsQueryable().Where(e => e.Codigo_Producto == Codigo);
            List<E_db_documento_producto> resultList = result.ToList();
            return resultList;

        }

        /// <summary>
        /// Descarga de documentos de un Tercero 
        /// </summary>
        /// <param name="documento"></param>           
        public async void Descargar_documento_producto(E_db_documento_producto documento)
        {
            var database = Mongo.Conexion();
            var fs = new GridFSBucket(database);
            var des1 = File.Create(Path.GetTempPath() + "\\" + documento.Documento);
            await fs.DownloadToStreamAsync(documento._id, des1);
            des1.Close();
            Process proceso = new Process();
            proceso.StartInfo.FileName = Path.GetTempPath() + "\\" + documento.Documento;
            proceso.Start();
            proceso.WaitForExit();
            proceso.Close();
        }

        /// <summary>
        /// Actualiza un documento de un Tercero 
        /// </summary>
        /// <param name="documento"></param>  
        /// <param name="estado"></param>  
   
        public async Task Editar_documento_producto(E_db_documento_producto documento, bool estado)
        {
            var database = Mongo.Conexion();
            var client = database.Client;
            //var database = MongoClient().GetDatabase("Smooper_ERP_data");
            using (var session = await client.StartSessionAsync())
            {
                session.StartTransaction();
                try
                {

                    var collection = database.GetCollection<E_db_documento_producto>("documentos_encabezado_producto");
                    var filter = Builders<E_db_documento_producto>.Filter.Eq("_id", documento._id);
                    if (estado)
                    {
                        collection.DeleteOne(filter);
                        var fs = new GridFSBucket(database);
                        fs.Delete(documento._id);
                        if (!await Documento_Producto(documento))
                        {
                            Environment.Exit(1);
                        }
                        new Windows().Notificacion("Documento actualizado con exito");
                    }
                    else
                    {



                        var update = Builders<E_db_documento_producto>.Update.Set(s => s.Nombre, documento.Nombre).Set(s => s.Documento, documento.Documento).Set(s => s.Fecha_expedicion, documento.Fecha_expedicion);
                        collection.UpdateOne(filter, update);


                    }
                    await session.CommitTransactionAsync();
                    new Windows().Alerta("Documento actualizado con exito");
                }

                catch (Exception ex)
                {
                    Console.WriteLine("Error actualizando datos en MongoDB: " + ex.Message);
                    new Windows().Alerta("El registro no se actualizo");

                    await session.AbortTransactionAsync();


                }

            }


        }

        /// <summary>
        /// Elimina un documento de un Tercero 
        /// </summary>
        /// <param name="_id"></param>          

        //public void Eliminar_Documento_Producto(ObjectId _id)
        //{
        //    var database = Mongo.Conexion();
        //    var collection = database.GetCollection<E_db_documento_producto>("documentos_encabezado_producto");
        //    var filter = Builders<E_db_documento_producto>.Filter.Eq("_id", _id);
        //    collection.DeleteOne(filter);
        //    var fs = new GridFSBucket(database);
        //    fs.Delete(_id);
        //}

        public async Task<bool> Eliminar_Documento_Producto(ObjectId _id)
        {
          
                var database = Mongo.Conexion();

                var client = database.Client;

                using (var session = await client.StartSessionAsync())
                {
                    session.StartTransaction();
                    try
                    {
                        var collection = database.GetCollection<E_db_documento_producto>("documentos_encabezado_producto");
                        var filter = Builders<E_db_documento_producto>.Filter.Eq("_id", _id);
                        collection.DeleteOne(filter);
                        var fs = new GridFSBucket(database);
                        fs.Delete(_id);
                        await session.CommitTransactionAsync();
                    }

                    catch (Exception e)
                    {
                        Console.WriteLine("Error eliminando datos en MongoDB: " + e.Message);
                        await session.AbortTransactionAsync();
                        return false;
                    }

                    return true;


                }
            }
          


        }

    }



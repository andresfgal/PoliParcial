"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const postSchema = new mongoose_1.Schema({
    created: {
        type: Date
    },
    mensaje: {
        type: String
    },
    imgs: [{
            type: String
        }],
    coords: {
        type: String // -13.313123, 12.3123123
    },
    precio: {
        type: String // 1000000
    },
    categoria: {
        type: String // Plana
    },
    estado: {
        type: String // usado
    },
    linea: {
        type: String // Industrial
    },
    sistema: {
        type: String // Mecanica
    },
    marca: {
        type: String // Singer
    },
    usuario: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Usuario',
        required: [true, 'Debe de existir una referencia a un usuario']
    }
});
postSchema.pre('save', function (next) {
    this.created = new Date();
    next();
});
exports.Post = mongoose_1.model('Maquinas', postSchema);


import express from 'express';


export default class Server {

    public app : express.Application;

    public port: any = process.env.PORT || 80;

    constructor() {
        this.app = express();
    }

    start( callback: Function ) {
        this.app.listen(process.env.PORT, () => {
            console.log(`server started on port ${process.env.PORT}`)
        });
    }

}